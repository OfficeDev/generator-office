"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.usageDataPromptMessage = exports.usageDataProjectName = exports.isVscodeInstalledEventName = exports.promptSelectionsErrorEventName = exports.promptSelectionstEventName = exports.postInstallHintsErrorEventName = exports.outlookSideloadingSteps = exports.networkShareSideloadingSteps = exports.installDependenciesErrorEventName = exports.copyFilesErrorEventName = exports.configurationErrorEventName = void 0;
const chalk = require("chalk");
exports.configurationErrorEventName = "configuration-error-generator-office";
exports.copyFilesErrorEventName = "copy-files-error-generator-office";
exports.installDependenciesErrorEventName = "install-dependencies-error-generator-office";
exports.networkShareSideloadingSteps = "https://learn.microsoft.com/office/dev/add-ins/testing/create-a-network-shared-folder-catalog-for-task-pane-and-content-add-ins";
exports.outlookSideloadingSteps = "https://learn.microsoft.com/office/dev/add-ins/outlook/sideload-outlook-add-ins-for-testing";
exports.postInstallHintsErrorEventName = "post-install-hints-error-generator-office";
exports.promptSelectionstEventName = "prompt-selections-generator-office";
exports.promptSelectionsErrorEventName = "prompt-selections-error-generator-office";
exports.isVscodeInstalledEventName = "if-vscode-installed-generator-office";
exports.usageDataProjectName = "generator-office";
exports.usageDataPromptMessage = `Office Add-in CLI tools collect anonymized usage data which is sent to Microsoft to help improve our product. Please read our privacy notice at ${chalk.blue('https://aka.ms/OfficeAddInCLIPrivacy')}. ​To disable data collection, choose Exit and run ${chalk.green('“npx office-addin-usage-data off”')}.\n\n`;
//# sourceMappingURL=defaults.js.map