"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.helperMethods = void 0;
const axios_1 = require("axios");
const fs = require("fs");
const path = require("path");
const unzip = require("unzipper");
const zipFile = 'project.zip';
// eslint-disable-next-line @typescript-eslint/no-namespace
var helperMethods;
(function (helperMethods) {
    function deleteFolderRecursively(projectFolder) {
        try {
            if (fs.existsSync(projectFolder)) {
                fs.readdirSync(projectFolder).forEach(function (file) {
                    const curPath = `${projectFolder}/${file}`;
                    if (fs.lstatSync(curPath).isDirectory()) {
                        deleteFolderRecursively(curPath);
                    }
                    else {
                        fs.unlinkSync(curPath);
                    }
                });
                fs.rmdirSync(projectFolder);
            }
        }
        catch (err) {
            throw new Error(`Unable to delete folder "${projectFolder}".\n${err}`);
        }
    }
    function doesProjectFolderExist(projectFolder) {
        if (fs.existsSync(projectFolder)) {
            return fs.readdirSync(projectFolder).length > 0;
        }
        return false;
    }
    helperMethods.doesProjectFolderExist = doesProjectFolderExist;
    ;
    function downloadProjectTemplateZipFile(projectFolder, projectRepo, projectBranch) {
        return __awaiter(this, void 0, void 0, function* () {
            const projectTemplateZipFile = `${projectRepo}/archive/${projectBranch}.zip`;
            return (0, axios_1.default)({
                method: 'get',
                url: projectTemplateZipFile,
                responseType: 'stream',
            }).then(response => {
                return new Promise((resolve, reject) => {
                    response.data.pipe(fs.createWriteStream(zipFile))
                        .on('error', function (err) {
                        reject(`Unable to download project zip file for "${projectTemplateZipFile}".\n${err}`);
                    })
                        .on('close', () => __awaiter(this, void 0, void 0, function* () {
                        yield unzipProjectTemplate(projectFolder);
                        resolve();
                    }));
                });
            }).catch(err => { console.log(`Unable to download project zip file for "${projectTemplateZipFile}".\n${err}`); });
        });
    }
    helperMethods.downloadProjectTemplateZipFile = downloadProjectTemplateZipFile;
    function unzipProjectTemplate(projectFolder) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                const zipFile = 'project.zip';
                const readStream = fs.createReadStream(`${projectFolder}/${zipFile}`);
                readStream.pipe(unzip.Extract({ path: projectFolder }))
                    .on('error', function (err) {
                    reject(`Unable to unzip project zip file for "${projectFolder}".\n${err}`);
                })
                    .on('close', () => __awaiter(this, void 0, void 0, function* () {
                    moveProjectFiles(projectFolder);
                    resolve();
                }));
            }));
        });
    }
    function moveProjectFiles(projectFolder) {
        // delete original zip file
        const zipFilePath = path.resolve(`${projectFolder}/${zipFile}`);
        if (fs.existsSync(zipFilePath)) {
            fs.unlinkSync(zipFilePath);
        }
        // get path to unzipped folder
        const unzippedFolder = fs.readdirSync(projectFolder).filter(function (file) {
            return fs.statSync(`${projectFolder}/${file}`).isDirectory();
        });
        // construct paths to move files out of unzipped folder into project root folder
        const moveFromFolder = path.resolve(`${projectFolder}/${unzippedFolder[0]}`);
        // loop through all the files and folders in the unzipped folder and move them to project root
        fs.readdirSync(moveFromFolder).forEach(function (file) {
            const fromPath = path.join(moveFromFolder, file);
            const toPath = path.join(projectFolder, file);
            if (fs.existsSync(fromPath) && !fromPath.includes(".gitignore")) {
                fs.renameSync(fromPath, toPath);
            }
        });
        // delete project zipped folder
        deleteFolderRecursively(moveFromFolder);
    }
})(helperMethods = exports.helperMethods || (exports.helperMethods = {}));
//# sourceMappingURL=helperMethods.js.map