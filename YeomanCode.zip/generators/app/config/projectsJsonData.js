"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const _ = require("lodash");
class projectsJsonData {
    constructor(templatePath) {
        this.m_projectJsonDataFile = '/projectProperties.json';
        const jsonData = fs.readFileSync(templatePath + this.m_projectJsonDataFile);
        this.m_projectJsonData = JSON.parse(jsonData.toString());
    }
    isValidInput(input, isHostParam) {
        if (isHostParam) {
            for (const key in this.m_projectJsonData.hostTypes) {
                if (_.toLower(input) == key) {
                    return true;
                }
            }
            return false;
        }
        else {
            for (const key in this.m_projectJsonData.projectTypes) {
                if (_.toLower(input) == key) {
                    return true;
                }
            }
            return false;
        }
    }
    getProjectDisplayName(projectType) {
        let displayName = this.m_projectJsonData.projectTypes[_.toLower(projectType)].displayname;
        return displayName;
    }
    getProjectDisplayNames() {
        const projectDisplayNames = [];
        for (const key in this.m_projectJsonData.projectTypes) {
            projectDisplayNames.push(this.getProjectDisplayName(key));
        }
        return projectDisplayNames;
    }
    getParsedProjectJsonData() {
        return this.m_projectJsonData;
    }
    getProjectTemplateNames() {
        const projectTemplates = [];
        for (const key in this.m_projectJsonData.projectTypes) {
            if (key != 'excel_sample' && key != 'word_sample' && key != 'excel_hello_world' && key != 'word_hello_world') {
                projectTemplates.push(key);
            }
        }
        return projectTemplates;
    }
    projectBothScriptTypes(projectType) {
        return this.m_projectJsonData.projectTypes[_.toLower(projectType)].templates.javascript != undefined && this.m_projectJsonData.projectTypes[_.toLower(projectType)].templates.typescript != undefined;
    }
    getManifestPath(projectType) {
        return this.m_projectJsonData.projectTypes[projectType].manifestPath;
    }
    getHostTemplateNames(projectType) {
        let hosts = [];
        for (const key in this.m_projectJsonData.projectTypes) {
            if (key === projectType) {
                hosts = this.m_projectJsonData.projectTypes[key].supportedHosts;
            }
        }
        return hosts;
    }
    getSupportedScriptTypes(projectType) {
        const scriptTypes = [];
        for (const template in this.m_projectJsonData.projectTypes[projectType].templates) {
            let scriptType;
            if (template === "javascript") {
                scriptType = "JavaScript";
            }
            else if (template === "typescript") {
                scriptType = "TypeScript";
            }
            scriptTypes.push(scriptType);
        }
        return scriptTypes;
    }
    getHostDisplayName(hostKey) {
        for (const key in this.m_projectJsonData.hostTypes) {
            if (_.toLower(hostKey) == key) {
                return this.m_projectJsonData.hostTypes[key].displayname;
            }
        }
        return undefined;
    }
    getProjectTemplateRepository(projectTypeKey, scriptType) {
        for (const key in this.m_projectJsonData.projectTypes) {
            if (_.toLower(projectTypeKey) == key) {
                if (projectTypeKey == 'manifest') {
                    return this.m_projectJsonData.projectTypes[key].templates.manifestonly.repository;
                }
                else {
                    return this.m_projectJsonData.projectTypes[key].templates[scriptType].repository;
                }
            }
        }
        return undefined;
    }
    getProjectTemplateBranchName(projectTypeKey, scriptType, prerelease) {
        for (const key in this.m_projectJsonData.projectTypes) {
            if (_.toLower(projectTypeKey) == key) {
                if (projectTypeKey == 'manifest') {
                    return this.m_projectJsonData.projectTypes.manifest.templates.branch;
                }
                else {
                    if (prerelease) {
                        return this.m_projectJsonData.projectTypes[key].templates[scriptType].prerelease;
                    }
                    else {
                        return this.m_projectJsonData.projectTypes[key].templates[scriptType].branch;
                    }
                }
            }
        }
        return undefined;
    }
    getProjectRepoAndBranch(projectTypeKey, scriptType, prerelease) {
        scriptType = scriptType === 'ts' ? 'typescript' : 'javascript';
        const repoBranchInfo = { repo: null, branch: null };
        repoBranchInfo.repo = this.getProjectTemplateRepository(projectTypeKey, scriptType);
        repoBranchInfo.branch = (repoBranchInfo.repo) ? this.getProjectTemplateBranchName(projectTypeKey, scriptType, prerelease) : undefined;
        return repoBranchInfo;
    }
}
exports.default = projectsJsonData;
//# sourceMappingURL=projectsJsonData.js.map